// ===================================
// SMARTHOME 4.0 — AUDITORIA & CORE
// ===================================

const $ = id => document.getElementById(id);

const defaults = {
  lights: [
    { name: "Sala", on: true, brightness: 80, watts: 18 },
    { name: "Quarto", on: false, brightness: 60, watts: 12 },
    { name: "Cozinha", on: false, brightness: 100, watts: 24 },
    { name: "Casa de banho", on: false, brightness: 75, watts: 15 }
  ],
  devices: [
    { name: "Aspirador inteligente", type: "vacuum", on: false, watts: 45 },
    { name: "Máquina de lavar", type: "washer", on: false, watts: 1800 },
    { name: "Ar condicionado", type: "air", on: false, watts: 1100 },
    { name: "Tomada inteligente", type: "plug", on: false, watts: 65 }
  ],
  blinds: [
    { name: "Sala", position: 100 },
    { name: "Quarto", position: 100 },
    { name: "Cozinha", position: 100 }
  ],
  doorLocked: true,
  windowsClosed: true,
  alarm: false,
  temperature: 22,
  climateMode: "Automático",
  cameras: [],
  history: [],
  vacuum: "Em repouso",
  darkMode: false,
  reminder: {
    enabled: false,
    time: "22:00",
    lastSent: ""
  }
};

function loadState() {
  try {
    const raw = JSON.parse(localStorage.getItem("smarthome40") || "{}");
    return {
      lights: Array.isArray(raw.lights) && raw.lights.length ? raw.lights : structuredClone(defaults.lights),
      devices: Array.isArray(raw.devices) && raw.devices.length ? raw.devices : structuredClone(defaults.devices),
      blinds: Array.isArray(raw.blinds) && raw.blinds.length ? raw.blinds : structuredClone(defaults.blinds),
      doorLocked: typeof raw.doorLocked === "boolean" ? raw.doorLocked : defaults.doorLocked,
      windowsClosed: typeof raw.windowsClosed === "boolean" ? raw.windowsClosed : defaults.windowsClosed,
      alarm: typeof raw.alarm === "boolean" ? raw.alarm : defaults.alarm,
      temperature: typeof raw.temperature === "number" ? Math.min(30, Math.max(16, raw.temperature)) : defaults.temperature,
      climateMode: typeof raw.climateMode === "string" ? raw.climateMode : defaults.climateMode,
      cameras: Array.isArray(raw.cameras) ? raw.cameras : [],
      history: Array.isArray(raw.history) ? raw.history : [],
      vacuum: typeof raw.vacuum === "string" ? raw.vacuum : defaults.vacuum,
      darkMode: Boolean(raw.darkMode),
      reminder: raw.reminder && typeof raw.reminder === "object"
        ? { ...defaults.reminder, ...raw.reminder }
        : structuredClone(defaults.reminder)
    };
  } catch {
    return structuredClone(defaults);
  }
}

let state = loadState();
let tvOn = false;
let isListening = false;

// ===================================
// GUARDAR DADOS & NOTIFICAÇÕES
// ===================================

function save() {
  try {
    localStorage.setItem("smarthome40", JSON.stringify(state));
  } catch (e) {
    console.warn("Falha ao guardar no localStorage:", e);
  }
}

function log(message) {
  const time = new Date().toLocaleTimeString("pt-PT", {
    hour: "2-digit",
    minute: "2-digit",
    second: "2-digit"
  });

  state.history.unshift({ message, time });
  state.history = state.history.slice(0, 60);

  save();
  renderHistory();
  renderDashboard();
}

function notify(message) {
  const container = $("toastContainer");
  while (container.children.length >= 3) {
    container.firstChild.remove();
  }

  const toast = document.createElement("div");
  toast.className = "toast";
  toast.textContent = message;
  container.appendChild(toast);

  setTimeout(() => {
    toast.style.opacity = "0";
    toast.style.transition = "opacity 0.25s";
    setTimeout(() => toast.remove(), 250);
  }, 3200);
}

function escapeHTML(value) {
  return String(value).replace(/[&<>"']/g, char => ({
    "&": "&amp;",
    "<": "&lt;",
    ">": "&gt;",
    '"': "&quot;",
    "'": "&#039;"
  })[char]);
}

// ===================================
// TEMA CLARO / ESCURO
// ===================================

function applyTheme() {
  document.body.classList.toggle("dark", state.darkMode);
  $("themeToggle").textContent = state.darkMode ? "☀️" : "🌙";
}

$("themeToggle").addEventListener("click", () => {
  state.darkMode = !state.darkMode;
  save();
  applyTheme();
});

// ===================================
// NAVEGAÇÃO
// ===================================

function showPage(page) {
  const target = $(page);
  if (!target) return;

  document.querySelectorAll(".page").forEach(p => p.classList.remove("active"));
  document.querySelectorAll(".nav").forEach(b => b.classList.remove("active"));

  target.classList.add("active");
  document.querySelector(`.nav[data-page="${page}"]`)?.classList.add("active");

  const titles = {
    dashboard: "Visão geral",
    lights: "Iluminação",
    climate: "Climatização",
    security: "Segurança",
    cameras: "Câmaras",
    blinds: "Estores",
    devices: "Aparelhos",
    tv: "Televisão",
    routines: "Rotinas",
    history: "Histórico"
  };

  $("pageTitle").textContent = titles[page] || page;
}

document.querySelectorAll(".nav").forEach(button => {
  button.addEventListener("click", () => showPage(button.dataset.page));
});

// ===================================
// CÁLCULO ENERGÉTICO & DASHBOARD
// ===================================

function calculateTotalWatts() {
  const lightsWatts = state.lights.reduce((acc, l) => {
    if (!l.on) return acc;
    const base = l.watts || 15;
    const factor = (l.brightness ?? 100) / 100;
    return acc + Math.round(base * factor);
  }, 0);

  const devicesWatts = state.devices.reduce((acc, d) => {
    return acc + (d.on ? (d.watts || 50) : 0);
  }, 0);

  const climateWatts = state.climateMode === "Desligado" ? 0 :
    (state.climateMode === "Ventilação" ? 60 : 450);

  const tvWatts = tvOn ? 110 : 0;

  return lightsWatts + devicesWatts + climateWatts + tvWatts;
}

function renderDashboard() {
  $("lightCount").textContent = state.lights.filter(x => x.on).length;
  $("deviceCount").textContent = state.devices.filter(x => x.on).length;

  const secEl = $("securityStatus");
  if (state.alarm) {
    secEl.textContent = "Armada";
    secEl.className = "alert-text";
  } else if (state.doorLocked && state.windowsClosed) {
    secEl.textContent = "Protegida";
    secEl.className = "success";
  } else {
    secEl.textContent = "Atenção";
    secEl.className = "warning";
  }

  $("tempValue").textContent = state.temperature + "°C";
  $("powerUsage").textContent = calculateTotalWatts() + " W";

  $("doorDashboard").textContent = state.doorLocked ? "Porta trancada" : "⚠️ Porta destrancada";
  $("vacuumDashboard").textContent = state.vacuum;

  $("recentHistory").innerHTML = state.history.length
    ? state.history.slice(0, 4).map(x => `<p>◷ ${x.time} — ${escapeHTML(x.message)}</p>`).join("")
    : "Ainda não existem atividades.";
}

const todayFormatted = new Date().toLocaleDateString("pt-PT", {
  weekday: "long",
  day: "numeric",
  month: "long"
});
$("today").textContent = todayFormatted.charAt(0).toUpperCase() + todayFormatted.slice(1);

// ===================================
// ILUMINAÇÃO
// ===================================

function toggleLightForm() {
  $("lightForm").classList.toggle("hidden");
}

function addLight() {
  const name = $("newLightName").value.trim();
  if (!name) {
    notify("Escreve o nome da divisão.");
    return;
  }
  state.lights.push({ name, on: false, brightness: 80, watts: 15 });
  $("newLightName").value = "";
  $("lightForm").classList.add("hidden");
  save();
  renderLights();
  log("Nova iluminação adicionada: " + name);
}

function deleteLight(index) {
  if (state.lights.length <= 1) {
    notify("Deves manter pelo menos uma iluminação.");
    return;
  }
  const removed = state.lights[index].name;
  state.lights.splice(index, 1);
  save();
  renderLights();
  renderDashboard();
  log("Iluminação removida: " + removed);
}

function renderLights() {
  $("lightsList").innerHTML = state.lights.map((light, i) => {
    const bri = light.brightness ?? 100;
    return `
      <div class="card light-card ${light.on ? "is-on" : ""}">
        <div class="card-header">
          <h3>💡 ${escapeHTML(light.name)}</h3>
          <div style="display:flex; align-items:center; gap:6px;">
            <span class="badge ${light.on ? "" : "off"}">${light.on ? bri + "%" : "OFF"}</span>
            ${i >= 4 ? `<button class="icon-delete" title="Remover" onclick="deleteLight(${i})">✕</button>` : ""}
          </div>
        </div>
        <p>${light.on ? "Iluminação ligada" : "Iluminação desligada"}</p>
        <input type="range" aria-label="Intensidade de ${escapeHTML(light.name)}" min="10" max="100" value="${bri}"
          ${!light.on ? "disabled" : ""}
          onchange="setLightBrightness(${i}, this.value)">
        <button class="${light.on ? "" : "secondary"}" onclick="toggleLight(${i})">
          ${light.on ? "Desligar" : "Ligar"}
        </button>
      </div>
    `;
  }).join("");
}

function setLightBrightness(index, value) {
  state.lights[index].brightness = Number(value);
  save();
  renderLights();
  renderDashboard();
  log(`Intensidade (${state.lights[index].name}): ${value}%`);
}

function toggleLight(index) {
  state.lights[index].on = !state.lights[index].on;
  save();
  renderLights();
  log(`Iluminação (${state.lights[index].name}): ${state.lights[index].on ? "ligada" : "desligada"}`);
}

function toggleAllLights() {
  const allOn = state.lights.every(x => x.on);
  state.lights.forEach(x => x.on = !allOn);
  save();
  renderLights();
  const msg = allOn ? "Todas as luzes desligadas" : "Todas as luzes ligadas";
  log(msg);
  notify(msg);
}

// ===================================
// CLIMATIZAÇÃO
// ===================================

function syncClimateUI() {
  $("temperature").textContent = state.temperature + "°C";
  $("climateMode").value = state.climateMode;
}

function changeTemp(amount) {
  state.temperature = Math.max(16, Math.min(30, state.temperature + amount));
  syncClimateUI();
  save();
  renderDashboard();
  log("Temperatura alterada para " + state.temperature + "°C");
}

function climateAction() {
  state.climateMode = $("climateMode").value;
  save();
  renderDashboard();
  log("Modo de climatização: " + state.climateMode);
  notify("Climatização: " + state.climateMode);
}

// ===================================
// SEGURANÇA & LEMBRETE
// ===================================

function renderSecurity() {
  $("doorStatus").textContent = state.doorLocked ? "🔒 Trancada" : "🔓 Destrancada";
  $("windowStatus").textContent = state.windowsClosed ? "Fechadas" : "Abertas";
  $("alarmStatus").textContent = state.alarm ? "🚨 Ativado" : "Desativado";

  $("reminderTime").value = state.reminder.time;
  $("reminderEnabled").checked = state.reminder.enabled;

  $("reminderStatus").textContent = state.reminder.enabled
    ? "Lembrete ativo para as " + state.reminder.time
    : "Lembrete desativado";
}

function toggleDoor() {
  state.doorLocked = !state.doorLocked;
  save();
  renderSecurity();
  renderDashboard();

  const msg = state.doorLocked ? "Porta trancada" : "Porta destrancada";
  log(msg);
  notify(state.doorLocked ? "🔒 " + msg : "🔓 " + msg);

  if (!state.doorLocked && state.alarm) {
    notify("⚠️ Atenção: a porta foi destrancada com o alarme ativo!");
  }
}

function toggleWindows() {
  state.windowsClosed = !state.windowsClosed;
  save();
  renderSecurity();
  renderDashboard();
  log(state.windowsClosed ? "Janelas fechadas" : "Janelas abertas");
}

function toggleAlarm() {
  state.alarm = !state.alarm;
  save();
  renderSecurity();
  renderDashboard();

  const msg = state.alarm ? "Alarme ativado" : "Alarme desativado";
  log(msg);
  notify("🚨 " + msg);
}

function saveReminder() {
  state.reminder.enabled = $("reminderEnabled").checked;
  state.reminder.time = $("reminderTime").value;

  if (!state.reminder.time) {
    notify("Escolhe uma hora válida.");
    return;
  }

  state.reminder.lastSent = "";
  save();
  renderSecurity();
  log("Configuração do lembrete da porta atualizada");
  notify("Lembrete guardado.");
}

async function enableNotifications() {
  if (!("Notification" in window)) {
    notify("O navegador não suporta notificações.");
    return;
  }

  const permission = await Notification.requestPermission();
  notify(permission === "granted" ? "🔔 Notificações ativadas!" : "Não foi concedida autorização.");
}

function checkReminder() {
  if (!state.reminder.enabled || state.doorLocked) return;

  const now = new Date();
  const currentTime =
    String(now.getHours()).padStart(2, "0") + ":" +
    String(now.getMinutes()).padStart(2, "0");

  const localToday = now.toLocaleDateString("sv-SE");

  if (currentTime === state.reminder.time && state.reminder.lastSent !== localToday) {
    const message = "⚠️ A porta continua destrancada!";
    notify(message);

    if ("Notification" in window && Notification.permission === "granted") {
      new Notification("SmartHome 4.0", { body: message });
    }

    state.reminder.lastSent = localToday;
    save();
    log(message);
  }
}

// ===================================
// CÂMARAS
// ===================================

function toggleCameraForm() {
  $("cameraForm").classList.toggle("hidden");
}

function isValidHttpUrl(string) {
  try {
    const parsed = new URL(string);
    return parsed.protocol === "http:" || parsed.protocol === "https:";
  } catch {
    return false;
  }
}

function renderCameras() {
  if (state.cameras.length === 0) {
    $("cameraList").innerHTML = `<p style="color:var(--muted);">Nenhuma câmara configurada. Clica em "Adicionar câmara".</p>`;
    return;
  }

  $("cameraList").innerHTML = state.cameras.map((camera, i) => {
    const safeUrl = escapeHTML(camera.url);
    return `
      <div class="card">
        <h3>📹 ${escapeHTML(camera.name)}</h3>
        <div class="camera-image">
          ${
            camera.url
              ? `<img src="${safeUrl}" alt="${escapeHTML(camera.name)}"
                    onerror="this.style.display='none'; this.parentElement.textContent='Imagem indisponível';">`
              : "Sem imagem configurada"
          }
        </div>
        <button class="danger" onclick="deleteCamera(${i})">Eliminar</button>
      </div>
    `;
  }).join("");
}

function addCamera() {
  const name = $("cameraName").value.trim();
  const url = $("cameraUrl").value.trim();

  if (!name) {
    notify("Escreve o nome da câmara.");
    return;
  }

  if (url && !isValidHttpUrl(url)) {
    notify("Utiliza um endereço HTTP ou HTTPS válido.");
    return;
  }

  state.cameras.push({ name, url });
  save();
  renderCameras();

  $("cameraName").value = "";
  $("cameraUrl").value = "";
  $("cameraForm").classList.add("hidden");

  log("Nova câmara adicionada: " + name);
  notify("Câmara adicionada.");
}

function deleteCamera(index) {
  const name = state.cameras[index].name;
  state.cameras.splice(index, 1);
  save();
  renderCameras();
  log("Câmara eliminada: " + name);
}

// ===================================
// ESTORES
// ===================================

function renderBlinds() {
  $("blindList").innerHTML = state.blinds.map((blind, i) => `
    <div class="card blind-card">
      <h3>🪟 Estore ${escapeHTML(blind.name)}</h3>
      <h2 id="blindValue${i}" style="color:var(--primary);">${blind.position}%</h2>
      <input type="range"
        aria-label="Posição do estore ${escapeHTML(blind.name)}"
        min="0"
        max="100"
        value="${blind.position}"
        oninput="previewBlind(${i}, this.value)"
        onchange="setBlind(${i}, this.value)">
      <p>0% Fechado · 100% Aberto</p>
      <button onclick="setBlind(${i}, 100)">Subir</button>
      <button onclick="setBlind(${i}, 0)">Descer</button>
      <button class="secondary" onclick="setBlind(${i}, 50)">50%</button>
    </div>
  `).join("");
}

function previewBlind(index, value) {
  $("blindValue" + index).textContent = value + "%";
}

function setBlind(index, value) {
  state.blinds[index].position = Number(value);
  save();
  renderBlinds();
  log("Estore " + state.blinds[index].name + ": " + value + "%");
}

// ===================================
// ELETRODOMÉSTICOS
// ===================================

function renderDevices() {
  const icons = {
    vacuum: "🧹",
    washer: "🧺",
    air: "❄️",
    plug: "🔌"
  };

  $("devicesList").innerHTML = state.devices.map((device, i) => `
    <div class="card device-card ${device.on ? "is-on" : ""}">
      <div class="card-header">
        <span class="big-icon" style="margin:0;">${icons[device.type] || "🔌"}</span>
        <span class="badge ${device.on ? "" : "off"}">${device.on ? (device.watts + "W") : "OFF"}</span>
      </div>
      <h3>${escapeHTML(device.name)}</h3>
      <p>${device.type === "vacuum" ? state.vacuum : (device.on ? "Ligado" : "Desligado")}</p>
      ${
        device.type === "vacuum"
          ? `
            <button onclick="vacuumAction('start')">Iniciar</button>
            <button class="secondary" onclick="vacuumAction('pause')">Pausar</button>
            <button class="secondary" onclick="vacuumAction('base')">Base</button>
          `
          : `
            <button class="${device.on ? "" : "secondary"}" onclick="toggleDevice(${i})">
              ${device.on ? "Desligar" : "Ligar"}
            </button>
          `
      }
    </div>
  `).join("");
}

function toggleDevice(index) {
  state.devices[index].on = !state.devices[index].on;
  save();
  renderDevices();
  renderDashboard();
  log(state.devices[index].name + (state.devices[index].on ? " ligado" : " desligado"));
}

function toggleVacuumQuick() {
  const vacuum = state.devices.find(x => x.type === "vacuum");
  vacuumAction(vacuum && vacuum.on ? "base" : "start");
}

function vacuumAction(action) {
  const vacuum = state.devices.find(x => x.type === "vacuum");
  if (!vacuum) return;

  if (action === "start") {
    state.vacuum = "A limpar";
    vacuum.on = true;
  } else if (action === "pause") {
    state.vacuum = "Em pausa";
    vacuum.on = false;
  } else if (action === "base") {
    state.vacuum = "A regressar à base";
    vacuum.on = false;
  }

  save();
  renderDevices();
  renderDashboard();
  log("Aspirador: " + state.vacuum);
  notify("🧹 Aspirador: " + state.vacuum);
}

// ===================================
// TELEVISÃO
// ===================================

function tvAction(command) {
  if (command === "Ligar / desligar") {
    tvOn = !tvOn;
    renderDashboard();
  }

  $("tvScreen").textContent = tvOn ? "SMART TV · LIGADA" : "SMART TV · STANDBY";
  $("tvFeedback").textContent =
    "Comando: " + command +
    (command === "Ligar / desligar" ? " — " + (tvOn ? "Ligada" : "Desligada") : "");

  log("Comando da televisão: " + command);
}

// ===================================
// ROTINAS
// ===================================

function routine(type) {
  if (type === "morning") {
    state.lights.forEach(x => x.on = true);
    state.blinds.forEach(x => x.position = 100);
    state.temperature = 22;
    state.climateMode = "Automático";
    syncClimateUI();
    notify("🌅 Rotina Bom dia executada!");
  } else if (type === "night") {
    state.lights.forEach(x => x.on = false);
    state.blinds.forEach(x => x.position = 0);
    state.doorLocked = true;
    notify("🌙 Rotina Boa noite executada!");
  } else if (type === "away") {
    state.lights.forEach(x => x.on = false);
    state.devices.forEach(x => x.on = false);
    state.vacuum = "Em repouso";
    state.alarm = true;
    state.doorLocked = true;
    notify("🏠 Modo ausência ativado!");
  }

  save();
  renderLights();
  renderBlinds();
  renderDevices();
  renderSecurity();
  renderDashboard();
  log("Rotina executada: " + type);
}

// ===================================
// HISTÓRICO & EXPORTAÇÃO
// ===================================

function renderHistory() {
  $("historyList").innerHTML = state.history.length
    ? state.history.map(item => `<p>◷ ${item.time} — ${escapeHTML(item.message)}</p>`).join("")
    : "Sem atividades registadas.";
}

function exportHistory() {
  if (!state.history.length) {
    notify("Não existem atividades para exportar.");
    return;
  }
  const content = state.history.map(h => `[${h.time}] ${h.message}`).join("\n");
  const blob = new Blob([content], { type: "text/plain;charset=utf-8" });
  const url = URL.createObjectURL(blob);
  const link = document.createElement("a");
  link.href = url;
  link.download = `historico-smarthome-${new Date().toLocaleDateString("sv-SE")}.txt`;
  link.click();
  URL.revokeObjectURL(url);
  notify("Registo exportado com sucesso.");
}

function clearHistory() {
  if (!confirm("Queres limpar o histórico?")) return;
  state.history = [];
  save();
  renderHistory();
  renderDashboard();
  notify("Histórico limpo.");
}

// ===================================
// COMANDO DE VOZ
// ===================================

const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;

function speak(message) {
  if (!("speechSynthesis" in window)) return;
  speechSynthesis.cancel();
  const utterance = new SpeechSynthesisUtterance(message);
  utterance.lang = "pt-PT";
  utterance.rate = 1;
  speechSynthesis.speak(utterance);
}

function voiceCommand(text) {
  const command = text.toLowerCase();

  for (let i = 0; i < state.lights.length; i++) {
    const room = state.lights[i].name.toLowerCase();
    if (command.includes(room)) {
      if (command.includes("ligar") || command.includes("acender")) {
        state.lights[i].on = true;
        save();
        renderLights();
        renderDashboard();
        log(`Luz (${state.lights[i].name}) ligada por voz`);
        return `Luz da divisão ${state.lights[i].name} ligada.`;
      }
      if (command.includes("desligar") || command.includes("apagar")) {
        state.lights[i].on = false;
        save();
        renderLights();
        renderDashboard();
        log(`Luz (${state.lights[i].name}) desligada por voz`);
        return `Luz da divisão ${state.lights[i].name} desligada.`;
      }
    }
  }

  if (command.includes("ligar todas as luzes") || command.includes("ligar luzes") || command.includes("acender luzes")) {
    state.lights.forEach(x => x.on = true);
    save();
    renderLights();
    renderDashboard();
    log("Luzes ligadas por voz");
    return "Todas as luzes foram ligadas.";
  }

  if (command.includes("desligar todas as luzes") || command.includes("desligar luzes") || command.includes("apagar luzes")) {
    state.lights.forEach(x => x.on = false);
    save();
    renderLights();
    renderDashboard();
    log("Luzes desligadas por voz");
    return "Todas as luzes foram desligadas.";
  }

  if (command.includes("temperatura")) {
    const match = command.match(/\d+/);
    if (match) {
      state.temperature = Math.max(16, Math.min(30, Number(match[0])));
      syncClimateUI();
      save();
      renderDashboard();
      log("Temperatura por voz: " + state.temperature + "°C");
      return `Temperatura ajustada para ${state.temperature} graus.`;
    }
  }

  if (command.includes("modo escuro")) {
    state.darkMode = true;
    save();
    applyTheme();
    return "Modo escuro ativado.";
  }

  if (command.includes("modo claro")) {
    state.darkMode = false;
    save();
    applyTheme();
    return "Modo claro ativado.";
  }

  if (command.includes("destrancar porta") || command.includes("abrir porta")) {
    state.doorLocked = false;
    save();
    renderSecurity();
    renderDashboard();
    log("Porta destrancada por voz");
    return "A porta foi destrancada.";
  }

  if (command.includes("trancar porta") || command.includes("fechar porta")) {
    state.doorLocked = true;
    save();
    renderSecurity();
    renderDashboard();
    log("Porta trancada por voz");
    return "A porta foi trancada.";
  }

  if (command.includes("ligar alarme") || command.includes("ativar alarme")) {
    state.alarm = true;
    save();
    renderSecurity();
    renderDashboard();
    log("Alarme ativado por voz");
    return "Alarme ativado.";
  }

  if (command.includes("desligar alarme") || command.includes("desativar alarme")) {
    state.alarm = false;
    save();
    renderSecurity();
    renderDashboard();
    log("Alarme desativado por voz");
    return "Alarme desativado.";
  }

  if (command.includes("subir estores") || command.includes("abrir estores")) {
    state.blinds.forEach(x => x.position = 100);
    save();
    renderBlinds();
    log("Estores subidos por voz");
    return "Todos os estores foram abertos.";
  }

  if (command.includes("descer estores") || command.includes("fechar estores")) {
    state.blinds.forEach(x => x.position = 0);
    save();
    renderBlinds();
    log("Estores descidos por voz");
    return "Todos os estores foram fechados.";
  }

  if (command.includes("iniciar aspirador")) {
    vacuumAction("start");
    return "Aspirador iniciado.";
  }

  if (command.includes("pausar aspirador")) {
    vacuumAction("pause");
    return "Aspirador em pausa.";
  }

  if (command.includes("abrir câmaras")) {
    showPage("cameras");
    return "A abrir câmaras.";
  }

  if (command.includes("abrir televisão")) {
    showPage("tv");
    return "A abrir comando da televisão.";
  }

  if (command.includes("abrir segurança")) {
    showPage("security");
    return "A abrir segurança.";
  }

  if (command.includes("abrir aparelhos")) {
    showPage("devices");
    return "A abrir aparelhos.";
  }

  if (command.includes("bom dia")) {
    routine("morning");
    return "Rotina de bom dia executada.";
  }

  if (command.includes("boa noite")) {
    routine("night");
    return "Rotina de boa noite executada.";
  }

  if (command.includes("modo ausência")) {
    routine("away");
    return "Modo ausência ativado.";
  }

  if (command.includes("que horas são")) {
    return "São " + new Date().toLocaleTimeString("pt-PT", { hour: "2-digit", minute: "2-digit" });
  }

  if (command.includes("ajuda")) {
    return "Podes dizer: ligar luz da sala, temperatura 23, trancar porta, subir estores, iniciar aspirador ou boa noite.";
  }

  return "Ainda não conheço esse comando.";
}

$("voiceButton").addEventListener("click", () => {
  if (!SpeechRecognition) {
    notify("O reconhecimento de voz não está disponível neste navegador.");
    return;
  }

  if (isListening) return;

  const recognition = new SpeechRecognition();
  recognition.lang = "pt-PT";
  recognition.continuous = false;
  recognition.interimResults = false;

  isListening = true;
  $("voiceButton").classList.add("listening");
  $("voiceButton").textContent = "🎙 A ouvir...";

  recognition.onresult = event => {
    const text = event.results[0][0].transcript;
    notify(`🗣️ "${text}"`);
    const response = voiceCommand(text);
    speak(response);
  };

  recognition.onerror = () => {
    notify("Não foi possível reconhecer a voz.");
  };

  recognition.onend = () => {
    isListening = false;
    $("voiceButton").classList.remove("listening");
    $("voiceButton").textContent = "🎙 Voz";
  };

  recognition.start();
});

// ===================================
// INICIALIZAÇÃO
// ===================================

function initialize() {
  applyTheme();
  syncClimateUI();
  renderDashboard();
  renderLights();
  renderSecurity();
  renderCameras();
  renderBlinds();
  renderDevices();
  renderHistory();

  setInterval(checkReminder, 10000);
}

initialize();
