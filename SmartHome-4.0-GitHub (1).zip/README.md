# SmartHome 4.0

Projeto de demonstração de uma casa inteligente.

## Como executar

Abre o ficheiro `index.html` num navegador ou publica o repositório com GitHub Pages.

## Ficheiros

- `index.html` — estrutura da aplicação
- `style.css` — estilos e layout
- `script.js` — funcionalidades e interações

## Nota

Esta versão é uma demonstração no navegador. Os controlos de luzes, fechadura, estores, câmaras e televisão não comandam equipamentos reais sem integração com dispositivos e serviços compatíveis. Os dados guardados no navegador usam armazenamento local.
